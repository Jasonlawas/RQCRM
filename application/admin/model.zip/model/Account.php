<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/1/10
 * Time: 16:55
 */
namespace app\admin\model;
use think\model;
class Account extends Model{
    //指定表名
    protected $table='crm_account';
}