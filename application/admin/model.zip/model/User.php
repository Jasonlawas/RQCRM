<?php
/**
 * Created by PhpStorm.
 * Crmuser: danei-php
 * Date: 2017/9/25
 * Time: 14:48
 */
namespace app\admin\model;
use think\Model;
class User extends Model{
    //指定表名
   protected $table='crm_user';
}